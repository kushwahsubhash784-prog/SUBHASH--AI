SUBHASH AI — Android mobile prototype

WHAT WORKS
- Dark SUBHASH AI interface
- Text input
- Browser speech recognition (Hindi) where supported
- Spoken responses using browser text-to-speech
- Installable PWA shell when hosted over HTTPS

IMPORTANT
This is a front-end prototype, not yet connected to an online AI model.
The current reply is a placeholder. To add real AI answers, create a secure
server/backend that stores the AI provider key privately and exposes a limited
chat endpoint. Do NOT put API keys in index.html or any public JavaScript file.

USE ON ANDROID
1. Upload these files to a static HTTPS host (for example GitHub Pages).
2. Open the hosted site in Chrome on Android.
3. Allow microphone permission.
4. Chrome menu > Add to Home screen / Install app.
5. For voice recognition, browser/device support and internet may be required.

The prototype uses browser SpeechRecognition and SpeechSynthesis. SpeechRecognition
support varies by browser and language.
